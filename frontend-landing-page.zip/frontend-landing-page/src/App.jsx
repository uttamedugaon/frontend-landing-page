
import { useState } from 'react'
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  Code2,
  Layers3,
  Menu,
  Palette,
  Smartphone,
  Sparkles,
  X,
  Zap,
} from 'lucide-react'

const services = [
  {
    number: '01',
    icon: Palette,
    title: 'UI/UX Design',
    description:
      'Thoughtful interfaces that make every interaction feel simple, intuitive, and memorable.',
    tags: ['Wireframes', 'Prototyping', 'Design systems'],
  },
  {
    number: '02',
    icon: Code2,
    title: 'Web Development',
    description:
      'Fast, scalable websites built with modern frontend technologies and clean code.',
    tags: ['React', 'Frontend', 'Performance'],
  },
  {
    number: '03',
    icon: Smartphone,
    title: 'Responsive Design',
    description:
      'Seamless experiences across phones, tablets, and desktop devices.',
    tags: ['Mobile-first', 'Accessibility', 'Testing'],
  },
]

const projects = [
  {
    number: '01',
    category: 'BRANDING · WEB DESIGN',
    title: 'Forma Studio',
    description: 'A refined digital home for a creative design studio.',
    style: 'from-[#dce6d4] to-[#b7c8ac]',
    accent: '#304932',
    label: 'forma.',
  },
  {
    number: '02',
    category: 'ECOMMERCE · DEVELOPMENT',
    title: 'Good Goods',
    description: 'A fresh shopping experience for everyday essentials.',
    style: 'from-[#f3d6bb] to-[#e7b78c]',
    accent: '#753c23',
    label: 'good things.',
  },
  {
    number: '03',
    category: 'PRODUCT · UI/UX',
    title: 'Flow Finance',
    description: 'A clearer way to understand your financial journey.',
    style: 'from-[#d7d8f5] to-[#aeb2e7]',
    accent: '#34356e',
    label: 'flow →',
  },
]

const process = [
  ['01', 'Discover', 'We understand your goals, audience, and what success looks like.'],
  ['02', 'Design', 'We turn ideas into clear layouts and visual systems.'],
  ['03', 'Develop', 'We build responsive interfaces with clean code.'],
  ['04', 'Deliver', 'We test across devices and prepare your project for launch.'],
]

function SectionLabel({ children }) {
  return (
    <p className="mb-4 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-[#647348]">
      <span className="h-2 w-2 rounded-full bg-[#a8ce58]" />
      {children}
    </p>
  )
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)

  function closeMenu() {
    setMenuOpen(false)
  }

  return (
    <div className="min-h-screen overflow-x-clip bg-[#fafaf6] text-[#172033]">
      {/* NAVBAR */}
      <header className="sticky top-0 z-50 border-b border-black/[0.06] bg-[#fafaf6]/95 backdrop-blur-xl">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8 lg:px-12">
          <a href="#home" onClick={closeMenu} className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#172033] text-[#c9f36a]">
              <Layers3 size={22} />
            </span>
            <span className="font-['Manrope'] text-xl font-extrabold tracking-tight">
              nexora<span className="text-[#789644]">.</span>
            </span>
          </a>

          <div className="hidden items-center gap-8 md:flex">
            <a href="#services" className="text-sm text-slate-600 transition hover:text-[#789644]">Services</a>
            <a href="#work" className="text-sm text-slate-600 transition hover:text-[#789644]">Our work</a>
            <a href="#process" className="text-sm text-slate-600 transition hover:text-[#789644]">Process</a>
          </div>

          <a
            href="#contact"
            className="hidden items-center gap-2 rounded-full bg-[#172033] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#34435d] md:flex"
          >
            Let's talk <ArrowUpRight size={16} />
          </a>

          <button
            type="button"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-black/10 md:hidden"
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </nav>

        {menuOpen && (
          <div className="border-t border-black/5 bg-[#fafaf6] px-5 py-4 md:hidden">
            <div className="mx-auto flex max-w-7xl flex-col gap-1">
              {[
                ['Services', '#services'],
                ['Our work', '#work'],
                ['Process', '#process'],
                ['Contact', '#contact'],
              ].map(([label, href]) => (
                <a
                  key={href}
                  href={href}
                  onClick={closeMenu}
                  className="rounded-xl px-4 py-3 font-medium hover:bg-[#edf0e5]"
                >
                  {label}
                </a>
              ))}
            </div>
          </div>
        )}
      </header>

      <main>
        {/* HERO SECTION */}
        <section id="home">
          <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10 lg:px-12 lg:py-24">
            <div className="relative z-10">
              <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-[#dce4cf] bg-white px-4 py-2 text-xs font-semibold text-[#52663a]">
                <Sparkles size={15} />
                DIGITAL EXPERIENCES, REIMAGINED
              </div>

              <h1 className="max-w-2xl font-['Manrope'] text-5xl font-extrabold leading-[1.08] tracking-[-0.055em] sm:text-6xl lg:text-7xl">
                Ideas into
                <br />
                impact<span className="text-[#88a84c]">.</span>
                <br />
                <span className="font-medium text-[#8a8f98]">Made digital.</span>
              </h1>

              <p className="mt-7 max-w-lg text-base leading-8 text-slate-600 sm:text-lg">
                We design and build thoughtful digital experiences that help
                ambitious brands stand out, connect, and grow.
              </p>

              <div className="mt-9 flex flex-wrap items-center gap-4">
                <a
                  href="#work"
                  className="group inline-flex items-center gap-3 rounded-full bg-[#c9f36a] px-6 py-4 font-bold transition hover:bg-[#b6e44d]"
                >
                  Explore our work
                  <ArrowDownRight size={19} className="transition group-hover:translate-x-1 group-hover:translate-y-1" />
                </a>
                <a
                  href="#services"
                  className="inline-flex items-center gap-2 px-3 py-3 text-sm font-semibold text-slate-700 hover:text-[#789644]"
                >
                  What we do <ArrowRight size={16} />
                </a>
              </div>

              <div className="mt-12 flex flex-wrap gap-x-7 gap-y-3 border-t border-black/10 pt-6 text-sm text-slate-500">
                <span className="flex items-center gap-2">
                  <Check size={16} className="text-[#789644]" />
                  Thoughtful design
                </span>
                <span className="flex items-center gap-2">
                  <Check size={16} className="text-[#789644]" />
                  Clean development
                </span>
              </div>
            </div>

            {/* HERO ILLUSTRATION */}
            <div className="relative mx-auto w-full max-w-xl">
              <div className="absolute -right-2 top-8 h-28 w-28 rounded-full bg-[#dce7cb] blur-2xl sm:right-8" />
              <div className="absolute -bottom-4 left-4 h-32 w-32 rounded-full bg-[#f3ddc5] blur-2xl" />

              <div className="relative rounded-[2rem] border border-white bg-[#e9eddf] p-4 shadow-[0_30px_90px_-40px_rgba(23,32,51,0.3)] sm:rounded-[2.5rem] sm:p-6">
                <div className="flex items-center justify-between rounded-2xl bg-white/80 px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 rounded-full bg-[#d4a69b]" />
                    <span className="h-2.5 w-2.5 rounded-full bg-[#e8c86c]" />
                    <span className="h-2.5 w-2.5 rounded-full bg-[#9bbd85]" />
                  </div>
                  <span className="text-[10px] font-bold tracking-[0.18em] text-slate-500">
                    NEXORA STUDIO
                  </span>
                </div>

                <div className="relative isolate mt-4 min-h-[340px] overflow-hidden rounded-[1.5rem] bg-[#172033] p-6 text-white sm:min-h-[390px] sm:p-9">
                  {/* Decorative circles remain behind the text */}
                  <div className="pointer-events-none absolute -right-16 -top-14 z-0 h-64 w-64 rounded-full border border-white/15 sm:h-80 sm:w-80" />
                  <div className="pointer-events-none absolute -right-7 -top-5 z-0 h-48 w-48 rounded-full border border-white/15 sm:h-64 sm:w-64" />

                  <div className="pointer-events-none absolute -bottom-24 -left-16 z-0 h-64 w-64 rounded-full bg-[#c9f36a] sm:h-80 sm:w-80" />

                  <div className="pointer-events-none absolute bottom-4 left-5 z-0 h-44 w-44 rotate-[-15deg] rounded-[2rem] border border-white/20 bg-white/10 sm:bottom-8 sm:left-10 sm:h-56 sm:w-56" />

                  {/* Main content: higher stacking layer */}
                  <div className="relative z-10 flex min-h-[292px] flex-col justify-between sm:min-h-[320px]">
                    <span className="text-xs font-extrabold uppercase tracking-[0.2em] text-[#c9f36a]">
                      Design meets purpose
                    </span>

                    <div className="relative z-20 mt-6">
                      <h2 className="font-['Manrope'] text-4xl font-extrabold leading-[1.12] tracking-[-0.04em] text-white sm:text-6xl">
                        Think.
                        <br />
                        Make.
                        <br />
                        <span className="front z-20 inline-block ">
                          Matter.
                        </span>
                      </h2>

                      <div className="mt-7 flex items-center justify-between gap-3 border-t border-white/30 pt-4">
                        <p className="text-xs font-medium text-white sm:text-sm">
                          A better digital tomorrow.
                        </p>
                        <a
                          href="#contact"
                          aria-label="Go to contact section"
                          className="relative z-30 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#c9f36a] text-[#172033] transition hover:scale-110"
                        >
                          <ArrowUpRight size={20} />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 px-1 pt-4 text-[9px] font-semibold tracking-wide text-slate-600 sm:px-2 sm:text-xs">
                  <span>CREATIVE THINKING</span>
                  <span>×</span>
                  <span>MODERN TECHNOLOGY</span>
                </div>
              </div>

              {/* Floating badge stays above illustration */}
              <div className="absolute -left-2 top-1/10 z-30 flex items-center gap-2 rounded-2xl border border-white bg-white px-3 py-3 shadow-lg sm:-left-7 sm:px-4">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#eef4df] text-[#627d39]">
                  <Zap size={19} />
                </span>
                <span className="whitespace-nowrap text-xs font-bold sm:text-sm">
                  Built for impact
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* SERVICES */}
        <section id="services" className="border-y border-black/[0.06] bg-white py-20 sm:py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
            <div className="mb-12 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
              <div>
                <SectionLabel>What we do</SectionLabel>
                <h2 className="font-['Manrope'] text-3xl font-extrabold tracking-tight sm:text-5xl">
                  Good ideas deserve
                  <br className="hidden sm:block" /> great execution.
                </h2>
              </div>
              <p className="max-w-sm leading-7 text-slate-500">
                From the first sketch to the final line of code, we focus on
                experiences that are useful, beautiful, and built to last.
              </p>
            </div>

            <div className="grid gap-5 md:grid-cols-3">
              {services.map(({ number, icon: Icon, title, description, tags }) => (
                <article
                  key={number}
                  className="group rounded-3xl border border-[#e8e9e3] bg-[#fafaf6] p-6 transition duration-300 hover:-translate-y-1 hover:border-[#c9d9a8] hover:shadow-xl sm:p-8"
                >
                  <div className="flex items-center justify-between">
                    <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#eaf0df] text-[#5d7538] transition group-hover:bg-[#c9f36a]">
                      <Icon size={23} />
                    </span>
                    <span className="text-sm font-semibold text-slate-400">{number}</span>
                  </div>
                  <h3 className="mt-8 font-['Manrope'] text-xl font-extrabold">{title}</h3>
                  <p className="mt-3 leading-7 text-slate-600">{description}</p>
                  <div className="mt-6 flex flex-wrap gap-2">
                    {tags.map((tag) => (
                      <span key={tag} className="rounded-full border border-[#e0e3d8] px-3 py-1.5 text-xs font-medium text-slate-600">
                        {tag}
                      </span>
                    ))}
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* PROJECTS */}
        <section id="work" className="py-20 sm:py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
            <div className="mb-12">
              <SectionLabel>Selected projects</SectionLabel>
              <h2 className="font-['Manrope'] text-3xl font-extrabold tracking-tight sm:text-5xl">
                A little work.
                <br /> A lot of thought.
              </h2>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {projects.map((project) => (
                <article key={project.number} className="group">
                  <div className={`relative flex aspect-[4/3] items-center justify-center overflow-hidden rounded-3xl bg-gradient-to-br ${project.style}`}>
                    <div className="absolute h-52 w-52 rotate-[-12deg] rounded-[42%_58%_55%_45%] border border-white/70 transition duration-500 group-hover:rotate-0 group-hover:scale-110" />
                    <div className="absolute h-36 w-36 translate-x-7 translate-y-5 rotate-[18deg] rounded-[40%] bg-white/20" />
                    <span className="relative z-10 px-4 text-center font-['Manrope'] text-4xl font-extrabold tracking-tight sm:text-5xl" style={{ color: project.accent }}>
                      {project.label}
                    </span>
                    <span className="absolute right-5 top-5 flex h-11 w-11 items-center justify-center rounded-full bg-white/80 transition group-hover:rotate-45">
                      <ArrowUpRight size={20} />
                    </span>
                  </div>
                  <div className="flex items-start justify-between gap-4 pt-5">
                    <div>
                      <p className="text-[10px] font-bold tracking-[0.16em] text-[#71864e]">{project.category}</p>
                      <h3 className="mt-2 font-['Manrope'] text-xl font-extrabold">{project.title}</h3>
                      <p className="mt-2 text-sm leading-6 text-slate-600">{project.description}</p>
                    </div>
                    <span className="pt-1 text-sm text-slate-400">{project.number}</span>
                  </div>
                </article>
              ))}
            </div>

            <p className="mt-8 text-xs text-slate-500">
              These are illustrative concept projects for this demonstration.
            </p>
          </div>
        </section>

        {/* PROCESS */}
        <section id="process" className="bg-[#172033] py-20 text-white sm:py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
            <SectionLabel>How we work</SectionLabel>
            <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
              <div>
                <h2 className="font-['Manrope'] text-3xl font-extrabold leading-tight tracking-tight sm:text-5xl">
                  Simple process.
                  <br />
                  <span className="text-[#c9f36a]">Better outcomes.</span>
                </h2>
                <p className="mt-6 max-w-md leading-8 text-white/65">
                  Great digital products don't happen by accident. Every step
                  has a purpose, and every detail has a reason.
                </p>
                <a
                  href="#contact"
                  className="mt-8 inline-flex items-center gap-2 rounded-full bg-[#c9f36a] px-5 py-3.5 font-bold text-[#172033] transition hover:bg-white"
                >
                  Start a conversation <ArrowRight size={17} />
                </a>
              </div>

              <div>
                {process.map(([number, title, description]) => (
                  <div key={number} className="flex gap-5 border-t border-white/15 py-6 sm:gap-8 sm:py-7">
                    <span className="pt-1 text-sm font-semibold text-[#c9f36a]">{number}</span>
                    <div>
                      <h3 className="font-['Manrope'] text-xl font-bold">{title}</h3>
                      <p className="mt-2 max-w-lg leading-7 text-white/60">{description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CONTACT */}
        <section id="contact" className="py-20 sm:py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
            <div className="relative overflow-hidden rounded-[2rem] bg-[#c9f36a] px-6 py-12 sm:rounded-[2.5rem] sm:px-12 sm:py-16 lg:px-16">
              <div className="pointer-events-none absolute -right-16 -top-24 h-72 w-72 rounded-full border-[36px] border-[#172033]/[0.06]" />
              <div className="relative z-10 max-w-3xl">
                <SectionLabel>Have a project in mind?</SectionLabel>
                <h2 className="font-['Manrope'] text-4xl font-extrabold leading-tight tracking-tight sm:text-6xl">
                  Let's make
                  <br />
                  something matter.
                </h2>
                <p className="mt-5 max-w-lg leading-7 text-slate-700">
                  Have an idea, a question, or a project you'd like to explore?
                  We'd love to hear from you.
                </p>
                <a
                  href="mailto:hello@example.com?subject=Project%20Enquiry"
                  className="mt-8 inline-flex items-center gap-3 rounded-full bg-[#172033] px-6 py-4 font-bold text-white transition hover:bg-[#34435d]"
                >
                  Get in touch <ArrowUpRight size={19} />
                </a>
                <p className="mt-3 text-xs text-slate-700">
                  Replace the demo email address before publishing.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-black/10 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-5 px-5 py-7 sm:px-8 md:flex-row md:items-center md:justify-between lg:px-12">
          <a href="#home" className="flex items-center gap-2 font-['Manrope'] text-lg font-extrabold">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#172033] text-[#c9f36a]">
              <Layers3 size={17} />
            </span>
            nexora<span className="text-[#789644]">.</span>
          </a>
          <p className="text-sm text-slate-500">
            © {new Date().getFullYear()} Nexora Digital. Built with purpose.
          </p>
          <a href="#home" className="inline-flex items-center gap-2 text-sm font-semibold hover:text-[#789644]">
            Back to top <ArrowUpRight size={16} />
          </a>
        </div>
      </footer>
    </div>
  )
}

export default App
